import React, { useState } from 'react';
import Card from '@mui/material/Card';
import CardMedia from '@mui/material/CardMedia';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';


const Ingredient = (props) => {
    // destructuring an object
    //const { name, image, calories} = props;
const list= props.ingredientsList;
const handleChange = (e) => {
  if (e.target.checked) {
    props.onAdd(e.target.id);
  } else {
    props.onRemove(e.target.id);
  }
}

  return (
<div>
{console.log(list)}
<div className="row">

    {list.map((ing)=> {
        return(           
                <div className='ingDiv col-3 col-lg-4' style={{ display: "inline-flex", margin: 5, width: 190, height:430 }}>
                  <Card sx={{ maxWidth: 345 }}>
                 <input type="checkbox" value={ing.Id} id={ing.Id} onChange={handleChange}></input>
                    <CardMedia
                      component="img"
                      height="190"
                      max-width="100%"
                      image={ing.Image}
                      alt={ing.Name} />
                    <CardContent>
                      <Typography variant="body2" color="text.secondary">
                        <h1> {ing.Name}</h1>
                        Calories: {ing.Calories}<br /><br />                                               
                      </Typography>
                    </CardContent>
                  </Card>
                  &nbsp;
                </div>                     
        );
    })}
    </div>
    </div>
  )
};

export default Ingredient;