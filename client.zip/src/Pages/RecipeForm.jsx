import React, { useState } from "react";
import Ingredient from "../Ingredient";
import { useEffect } from "react";
import Stack from "@mui/material/Stack";
import Button from "@mui/material/Button";

function RecipeForm(props) {
  const [name, setRecipeName] = useState("");
  const [recipeImage, setImage] = useState("");
  const [cookingMethod, setCookingmethod] = useState("");
  const [cookingTime, setRecipeTime] = useState("");
  const [ingredientsList, SetIngredientsList] = useState([]); // a list of ingredients
  const apiIngUrl = "http://localhost:49231/api/ingredient/";
  const apiRecipeUrl = "http://localhost:49231/api/recipes/";
  let recpieIngerdaintsId = [];

  useEffect(() => {
    fetch(apiIngUrl, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    })
      .then((res) => res.json())
      .then((result) => {
        SetIngredientsList(result);
        console.log(ingredientsList);
      });
  }, []);

  const handleAdd = (id) => {
    recpieIngerdaintsId.push(id);
  };
  const handleRemove = (id) => {
    recpieIngerdaintsId = recpieIngerdaintsId.filter((item) => item !== id);
  };

  const btnPostRecipe = (
    name,
    recipeImage,
    cookingMethod,
    cookingTime,
    recpieIngerdaintsId
  ) => {
    const recipe = {
      //pay attention case sensitive!!!! should be exactly as the prop in C#!
      Name: name,
      Image: recipeImage,
      CookingMethod: cookingMethod,
      Time: cookingTime,
      Ingredients: recpieIngerdaintsId,
    };

    fetch(apiRecipeUrl, {
      method: "POST",
      body: JSON.stringify(recipe),
      headers: new Headers({
        "Content-type": "application/json; charset=UTF-8", //very important to add the 'charset=UTF-8'!!!!
        Accept: "application/json; charset=UTF-8",
      }),
    })
      .then((response) => {
        console.log("res=", response);
        return response.json();
      })
      .then(
        (result) => {
          console.log("fetch POST= ", result);
          console.log(result.Time);
        },
        (error) => {
          console.log("err post=", error);
        }
      );
  };

  return (
    <div>
      <h3>Add New Recipe</h3>
      <form style={{ display: "inline-block", marginBottom: "1rem" }}>
        <div className="form-group" style={{ display: "flex", marginBottom: "1rem" }}>
          <p style={{ marginRight: "1rem" }}>Recipe Name</p>
          <input
            className="recipie-input"
            type="text"
            name="name"
            placeholder="Recipe Name"
            onChange={(e) => setRecipeName(e.target.value)}
          />
        </div>
        <div className="form-group" style={{ display: "flex", marginBottom: "1rem" }}>
          <p style={{ marginRight: "1rem" }}>Recipe Image</p>
          <input
            className="recipie-input"
            type="text"
            name="name"
            placeholder="Recipe Image"
            onChange={(e) => setImage(e.target.value)}
          />
        </div>
        <div className="form-group" style={{ display: "flex", marginBottom: "1rem" }}>
          <p style={{ marginRight: "1rem" }}>Recipe Cooking Method</p>
          <input
            className="recipie-input"
            type="text"
            name="name"
            placeholder="Recipe Cooking Method"
            onChange={(e) => setCookingmethod(e.target.value)}
          />
        </div>
        <div className="form-group" style={{ display: "flex", marginBottom: "1rem" }}>
          <p style={{ marginRight: "1rem" }}>Recipe Cooking Time</p>
          <input
            className="recipie-input"
            type="number"
            name="name"
            placeholder="Recipe Cooking Time"
            onChange={(e) => setRecipeTime(e.target.value)}
          />
        </div>
        <br />
        <Stack>
          <Button
            type="submit"
            variant="contained"
            style={{ backgroundColor: "white", color: "brown" }}
            onClick={() =>
              btnPostRecipe(
                name,
                recipeImage,
                cookingMethod,
                cookingTime,
                recpieIngerdaintsId
              )
            }
          >
            Add Recipe
          </Button>
        </Stack>
      </form>
      <br />
      <br />
      <Ingredient
        ingredientsList={ingredientsList}
        onAdd={handleAdd}
        onRemove={handleRemove}
      />
    </div>
  );
}

export default RecipeForm;
