import React, { useState } from "react";
import { useEffect } from "react";
import IngredientInRecipe from "./IngredientInRecipe";
import Card from "@mui/material/Card";
import CardMedia from "@mui/material/CardMedia";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
import { images } from "./image";
import { HomeContainer, HomeContentContainer } from "./style2";
import Button from "@mui/material/Button";
import Modal from "react-modal";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
};

export default function Home() {
  const apiRecipeUrl = "http://localhost:49231/api/recipes/";
  const [recipeList, SetRecipesList] = useState([]); // a list of ingredients
  const [open, setOpen] = React.useState(false);
  const [modalIsOpen, setIsOpen] = useState(false);

  useEffect(() => {
    fetch(apiRecipeUrl, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    })
      .then((res) => res.json())
      .then((result) => {
        SetRecipesList(result);
        console.log(recipeList);
      });
  }, []);

  function openModal() {
    setIsOpen(true);
  }

  function closeModal() {
    setIsOpen(false);
  }
  const customStyles = {
    content: {
      top: "50%",
      left: "50%",
      right: "auto",
      bottom: "auto",
      marginRight: "-50%",
      transform: "translate(-50%, -50%)",
    },
  };

  return (
    <>
      <HomeContainer>
        <HomeContentContainer>
          <div className="row">
            <div className="col-12">
              <h1>My Recipes </h1>
              <p>
                Welcome to my recipe site, you will find all kinds of recipes
                here. So, shall we cook?
              </p>
            </div>
          </div>
          <div className="row">
            <div className="img-fluid">
              <img src={images} />
            </div>
          </div>
        </HomeContentContainer>
      </HomeContainer>
      <div className="allRecipes" style={{ display: "initial" }}>
        <br />
        <br />
        <br />
        <br />

        <div className="row">
          {recipeList.map((recipe) => {
            return (
              <div
                className="col-12 col-md-6 col-lg-3 p-4"
                style={{
                  display: "inline-flex",
                  margin: 5,
                  width: 220,
                  height: 430,
                }}
              >
                <Card sx={{ maxWidth: 345 }}>
                  <CardMedia
                    component="img"
                    height="190"
                    max-width="100%"
                    image={recipe.Image}
                    alt={recipe.Name}
                  />
                  <CardContent>
                    <Typography variant="body2" color="text.secondary">
                      <h1> {recipe.Name}</h1>
                      Cooking Method: {recipe.CookingMethod}
                      <br />
                      <br />
                      Time: {recipe.Time} minutes <br />
                      <br />
                      <Button onClick={openModal}>See ingredients</Button>
                      <Modal
                        isOpen={modalIsOpen}
                        onRequestClose={closeModal}
                        style={customStyles}
                        ariaHideApp={false}
                        contentLabel="Example Modal"
                      >
                        <h2>{recipe.Name} Ingerdaints: </h2>
                        {recipe.Ingredients.map((ingInRecipe, ind) => (
                          <IngredientInRecipe
                            ingInRecipe={ingInRecipe}
                            key={ind}
                          />
                        ))}
                        <br/>
                        <button onClick={closeModal}>close</button>
                      </Modal>
                    </Typography>
                  </CardContent>
                </Card>
                &nbsp;
              </div>
            );
          })}
        </div>
      </div>
    </>
  );
}
