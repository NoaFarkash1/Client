import Card from "react-bootstrap/Card";
import React, { useState } from "react";
import { useEffect } from "react";

export default function IngredientInRecipe(props) {
  const ingInRecipe = props.ingInRecipe;
  const apiIngUrl = "http://localhost:49231/api/ingredient/Get/";
  const [ing, SetIng] = useState("");

  useEffect(() => {
   
    fetch(apiIngUrl + ingInRecipe, {
      method: "GET",
      headers: new Headers({
        "Content-Type": "application/json; charset=UTF-8",
        Accept: "application/json; charset=UTF-8",
      }),
    })
      .then((res) => {
        return res.json();
      })
      .then(
        (result) => {

          SetIng(result);
          console.log(result,"dadsda")
          console.log(ing);
        },
        (error) => {
          console.log("err post=", error);
        }
      );
  }, []);

  return(
    <div>{ing.Name}</div>
  )
}
