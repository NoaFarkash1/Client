import React, { useState } from "react";
import Stack from "@mui/material/Stack";
import Button from "@mui/material/Button";
// name, cookingtime, ingredients

const Ingredientform = (props) => {
  const [name, setName] = useState("");
  const [ingImage, setImage] = useState(0);
  const [ingCalories, setIngCalories] = useState("");
  const apiIngUrl = "http://localhost:49231/api/ingredient/";

  const btnPostIng = (name, ingImage, ingCalories) => {
    const ing = {
      //pay attention case sensitive!!!! should be exactly as the prop in C#!
      Name: name,
      Image: ingImage,
      Calories: ingCalories,
    };

    fetch(apiIngUrl, {
      method: "POST",
      body: JSON.stringify(ing),
      headers: new Headers({
        "Content-type": "application/json; charset=UTF-8", //very important to add the 'charset=UTF-8'!!!!
        Accept: "application/json; charset=UTF-8",
      }),
    })
      .then((response) => {
        console.log("res=", response);
        return response.json();
      })
      .then(
        (result) => {
          console.log("fetch POST= ", result);
          console.log(result.Calories);
        },
        (error) => {
          console.log("err post=", error);
        }
      );
  };

  // onChange -  everytime one of the input field/value changes, it will set the state automatically and can access the changes state in handleAdd

  return (
    <div>
      <h3>Add New Ingredient</h3>
      <form>
        <div style={{ display: "flex", marginBottom: "1rem" }}>
          <p style={{ marginRight: "1rem" }}>Ingredient Name</p>
          <input
            className="recipie-input"
            type="text"
            name="name"
            placeholder="Ingredient Name"
            onChange={(e) => setName(e.target.value)}
          />
        </div>
        <div style={{ display: "flex", marginBottom: "1rem" }}>
          <p style={{ marginRight: "1rem" }}>Ingredient Image</p>
          <input
            className="recipie-input"
            type="text"
            name="name"
            placeholder="Ingredient Image"
            onChange={(e) => setImage(e.target.value)}
          />
        </div>
        <div style={{ display: "flex", marginBottom: "1rem" }}>
          <p style={{ marginRight: "1rem" }}>Ingredient calories</p>
          <input
            className="recipie-input"
            type="number"
            name="name"
            placeholder="Ingredient Calories"
            onChange={(e) => setIngCalories(e.target.value)}
          />
        </div>
        <br />
        <Stack>
          <Button
            type="submit"
            variant="contained"
            style={{ backgroundColor: "white", color: "brown" }}
            onClick={() => btnPostIng(name, ingImage, ingCalories)}
          >
            Add ingredient
          </Button>
        </Stack>
      </form>
    </div>
  );
};

export default Ingredientform;
